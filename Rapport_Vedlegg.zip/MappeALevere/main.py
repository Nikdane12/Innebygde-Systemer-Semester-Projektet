from tkinter import *
from tkinter import ttk
from adafruit_servokit import ServoKit
import time
import math
import hx711

from gpiozero import OutputDevice
from gpiozero import Button as GPIOButton
pump_fwd = OutputDevice(21, initial_value=False)

kit = ServoKit(channels=16)

def drive(midje, skulder, albue, wrist, pump):
    min = 2350
    max = 5650

    def angle_to_us(deg):
        return int(max - ((max - min) * (deg / 90)))

    kit._pca.channels[0].duty_cycle = 65535 - angle_to_us(midje)
    kit._pca.channels[1].duty_cycle = 65535 - angle_to_us(skulder)
    kit._pca.channels[2].duty_cycle = 65535 - angle_to_us(albue)
    kit._pca.channels[3].duty_cycle = 65535 - angle_to_us(wrist)
    
    desired_duty = int(pump / 100 * 65535)
    kit._pca.channels[4].duty_cycle = 65535 - desired_duty
 
#state machine
activate     = False
fill_state  = "idle"   # idle / moving / filling

#arm dimetions (cm)
L1     = 15.0   # arm_1
L2     = 15.0   # arm_2
L3     = 5.0    # wrist
Z_BASE =  5.0   # base height

#servo angle offsets (deg)
MOUNT_SKULDER = 45.0 
MOUNT_ALBUE   =  0.0
MOUNT_WRIST   =  0.0

def solve_ik(x, y, z, phi_deg, elbow_up=True):
    phi = math.radians(phi_deg)

    #base rotation
    theta_base = math.atan2(y, x)
    r = math.hypot(x, y)

    #wrist point in planar
    xw = r - L3 * math.cos(phi)
    yw = (z - Z_BASE) - L3 * math.sin(phi)

    #albue
    cos_t2 = (xw**2 + yw**2 - L1**2 - L2**2) / (2 * L1 * L2)
    cos_t2 = max(-1.0, min(1.0, cos_t2))   # clamp for numerical safety

    sign = 1 if elbow_up else -1
    sin_t2 = sign * math.sqrt(1 - cos_t2**2)
    theta2 = math.atan2(sin_t2, cos_t2)

    #skulder
    theta1 = math.atan2(yw, xw) - math.atan2(L2 * sin_t2, L1 + L2 * cos_t2)

    #wrist
    theta3 = phi - theta1 - theta2

    #offsets: world-space angles -> servo degrees
    return (
        math.degrees(theta_base),
        math.degrees(theta1) - MOUNT_SKULDER,
        math.degrees(theta2) - MOUNT_ALBUE,
        math.degrees(theta3) - MOUNT_WRIST,
    )

#PID verdier
kp = 0.5
ki = 0.1
kd = 0.00

integral = 0
prev_error = 0
prev_time = time.time()

def pid_control(setpoint, measurement, integral, prev_error, prev_time):
    error = setpoint - measurement
    current_time = time.time()
    dt = current_time - prev_time

    if dt <= 0:
        return 0, integral, error, current_time

    integral += error * dt
    derivative = (error - prev_error) / dt

    output = kp * error + ki * integral + kd * derivative

    return output, integral, error, current_time

#GUI
root = Tk()
root.title("Arm Controller")
root.geometry("800x800")

#main window
canvas  = Canvas(root)
vscroll = Scrollbar(root, orient=VERTICAL, command=canvas.yview)
canvas.configure(yscrollcommand=vscroll.set)
vscroll.pack(side=RIGHT, fill=Y)
canvas.pack(side=LEFT, fill=BOTH, expand=True)
main = Frame(canvas)
canvas_window = canvas.create_window((0, 0), window=main, anchor="nw")

def on_frame_configure():
    canvas.configure(scrollregion=canvas.bbox("all"))
def on_canvas_configure(e):
    canvas.itemconfig(canvas_window, width=e.width)
main.bind("<Configure>", on_frame_configure)
canvas.bind("<Configure>", on_canvas_configure)
def _on_mousewheel(e):
    if e.num == 4:
        canvas.yview_scroll(-1, "units")
    elif e.num == 5:
        canvas.yview_scroll(1, "units")
    elif e.delta:
        canvas.yview_scroll(-1 * (e.delta // 120), "units")

root.bind_all("<MouseWheel>", _on_mousewheel)
root.bind_all("<Button-4>", _on_mousewheel)
root.bind_all("<Button-5>", _on_mousewheel)
midje_var   = DoubleVar(value=0)
skulder_var = DoubleVar(value=0)
albue_var   = DoubleVar(value=0)
wrist_var   = DoubleVar(value=0)
pump_var    = DoubleVar(value=0)

JOINT_VARS = [midje_var, skulder_var, albue_var, wrist_var, pump_var]

def get_joints():
    return [v.get() for v in JOINT_VARS]

def set_joints(values):
    for var, val in zip(JOINT_VARS, values):
        var.set(val)
    drive(*values)

Label(main, text=" Joint Control ", font=("Segoe UI", 11, "bold")).pack(pady=(10, 2))

def make_slider(label, var, from_, to):
    f = Frame(main)
    f.pack(fill="x", padx=20, pady=1)
    Label(f, text=label, width=8, anchor="w").pack(side=LEFT)
    s = Scale(f, variable=var, from_=from_, to=to, orient=HORIZONTAL,
              length=380, resolution=1)
    s.pack(side=LEFT, fill="x", expand=True)
    s.config(command=lambda _: drive(*get_joints()))

make_slider("Midje",   midje_var,  45, -45)
make_slider("Skulder", skulder_var, 45, -45)
make_slider("Albue",   albue_var,   45, -45)
make_slider("Wrist",   wrist_var,   45, -45)

def on_pump_slider(_):
    pct = int(pump_var.get())
    if pct == 0:
        pump_fwd.off()
    else:
        pump_fwd.on()
    drive(*get_joints())

f_pump = Frame(main)
f_pump.pack(fill="x", padx=20, pady=1)
Label(f_pump, text="Pump", width=8, anchor="w").pack(side=LEFT)
pump_scale = Scale(f_pump, variable=pump_var, from_=0, to=100,
                   orient=HORIZONTAL, length=380, resolution=1,
                   command=on_pump_slider)
pump_scale.pack(side=LEFT, fill="x", expand=True)

def reset_all():
    set_joints([0, 0, 0, 0, 0])

Button(main, text="Reset", command=reset_all).pack(pady=4)

def toggle_activate():
    global activate
    activate = not activate
    activate_btn.config(
        text="Deactivate" if activate else "Activate Main Program",
        bg="red" if activate else activate_btn_default_bg
    )

activate_btn = Button(main, text="Activate Main Program", command=toggle_activate,
                      font=("Segoe UI", 10, "bold"), width=24)
activate_btn.pack(pady=6)
activate_btn_default_bg = activate_btn.cget("bg")

#IK input 
Label(main, text=" Inverse Kinematics ", font=("Segoe UI", 11, "bold")).pack(pady=(14, 2))

ik_frame = Frame(root)
ik_frame.pack(padx=20, fill="x")

def entry_row(parent, label, default):
    f = Frame(parent)
    f.pack(fill="x", pady=1)
    Label(f, text=label, width=12, anchor="w").pack(side=LEFT)
    var = DoubleVar(value=default)
    Entry(f, textvariable=var, width=8).pack(side=LEFT)
    return var

ik_x              = entry_row(ik_frame, "X (cm)",          15.0)
ik_y              = entry_row(ik_frame, "Y (cm)",           0.0)
ik_z              = entry_row(ik_frame, "Z (cm)",          10.0)
ik_phi            = entry_row(ik_frame, "φ orient°",        0.0)
ik_zbase          = entry_row(ik_frame, "Base ht (cm)",   Z_BASE)
ik_mount_skulder  = entry_row(ik_frame, "Skulder mount°", MOUNT_SKULDER)

ik_status = Label(main, text="", fg="red")
ik_status.pack()

def run_ik():
    try:
        global Z_BASE, MOUNT_SKULDER
        Z_BASE        = ik_zbase.get()
        MOUNT_SKULDER = ik_mount_skulder.get()
        base, t1, t2, t3 = solve_ik(
            ik_x.get(), ik_y.get(), ik_z.get(), ik_phi.get()
        )
        target = [base, t1, t2, t3, pump_var.get()]
        global move_start, move_target
        move_start  = get_joints()
        move_target = target
        smooth_step(0)
        ik_status.config(text=f"M:{base:+.1f}°  S:{t1:+.1f}°  A:{t2:+.1f}°  W:{t3:+.1f}°", fg="green")
    except Exception as e:
        ik_status.config(text=str(e), fg="red")

#kontrollere hastigheten
move_start  = [0.0] * 5
move_target = [0.0] * 5
MOVE_STEPS   = 40
MOVE_MS      = 15   # ms/step

f_speed = Frame(main)
f_speed.pack(fill="x", padx=20, pady=(4, 0))
Label(f_speed, text="Speed", width=8, anchor="w").pack(side=LEFT)
speed_var = IntVar(value=MOVE_MS)
Label(f_speed, text="Fast", width=4).pack(side=LEFT)
Scale(f_speed, variable=speed_var, from_=5, to=80,
      orient=HORIZONTAL, length=300, resolution=5,
      command=lambda v: set_speed(int(v))
      ).pack(side=LEFT)

def set_speed(v):
    global MOVE_MS
    MOVE_MS = v
Label(f_speed, text="Slow").pack(side=LEFT)

#positions
Label(main, text=" Saved Positions ", font=("Segoe UI", 11, "bold")).pack(pady=(14, 2))

NUM_POS = 3
saved   = [None] * NUM_POS

def smooth_step(step):
    t = step / MOVE_STEPS
    t = t * t * (3 - 2 * t)
    interp = [move_start[i] + (move_target[i] - move_start[i]) * t for i in range(5)]
    set_joints(interp)
    if step < MOVE_STEPS:
        root.after(MOVE_MS, lambda: smooth_step(step + 1))

def go_to(idx):
    if saved[idx] is None:
        return
    global move_start, move_target
    move_start  = get_joints()
    move_target = list(saved[idx])
    smooth_step(0)

def save_pos(idx):
    saved[idx] = get_joints()
    m, s, a, w, p = saved[idx]
    pos_labels[idx].config(
        text=f"M:{m:+.0f}°  S:{s:+.0f}°  A:{a:+.0f}°  W:{w:+.0f}°  P:{p:.0f}%"
    )
    go_btns[idx].config(state=NORMAL)

pos_labels = []
go_btns    = []

for i in range(NUM_POS):
    f = Frame(main, relief="groove", bd=1)
    f.pack(fill="x", padx=20, pady=3)
    Label(f, text=f"Position {i+1}", font=("Segoe UI", 9, "bold"), width=10).pack(side=LEFT, padx=4)
    lbl = Label(f, text="(empty)", anchor="w", width=32)
    lbl.pack(side=LEFT)
    pos_labels.append(lbl)
    Button(f, text="Save", width=5, command=lambda i=i: save_pos(i)).pack(side=LEFT, padx=2)
    go = Button(f, text="Go", width=4, state=DISABLED, command=lambda i=i: go_to(i))
    go.pack(side=LEFT, padx=2)
    go_btns.append(go)

#load cells
Label(main, text=" Load Cell ", font=("Segoe UI", 11, "bold")).pack(pady=(14, 2))

use_median = False

for lbl_text, lbl_var in [("Sensor 1", None), ("Sensor 2", None), ("Sensor 3", None)]:
    Label(main, text=lbl_text, font=("Segoe UI", 9)).pack()

weight_lbl1 = Label(main, text="-- g", font=("Segoe UI", 24, "bold"))
weight_lbl2 = Label(main, text="-- g", font=("Segoe UI", 24, "bold"))
weight_lbl3 = Label(main, text="-- g", font=("Segoe UI", 24, "bold"))
weight_lbl1.pack()
weight_lbl2.pack()
weight_lbl3.pack()

mode_btn = Button(main, text="Mode: Live", width=16)
mode_btn.pack(pady=4)

def toggle_mode():
    global use_median
    use_median = not use_median
    mode_btn.config(text="Mode: Median" if use_median else "Mode: Live")

mode_btn.config(command=toggle_mode)

def read(sensor):
    if use_median:
        return (sensor.read_median() - sensor.hx_offset) / sensor.scale_factor
    return sensor.read_grams()

def poll_hx711():
    interval = 500 if use_median else 200
    for sensor, lbl in [(hx711.sensor1, weight_lbl1),
                        (hx711.sensor2, weight_lbl2),
                        (hx711.sensor3, weight_lbl3)]:
        try:
            lbl.config(text=f"{read(sensor):.1f} g")
        except Exception:
            lbl.config(text="err")
    root.after(interval, poll_hx711)

sensors = [hx711.sensor1, hx711.sensor2, hx711.sensor3]

def open_calibration():
    win = Toplevel(root)
    win.title("Load Cell Calibration")
    win.resizable(False, False)

    for i, sensor in enumerate(sensors):
        frame = LabelFrame(win, text=f"Sensor {i+1}", padx=10, pady=6)
        frame.pack(fill="x", padx=12, pady=6)

        reading_lbl = Label(frame, text="-- g", font=("Segoe UI", 13, "bold"), width=10)
        reading_lbl.pack(side=RIGHT)

        def refresh(lbl=reading_lbl, s=sensor):
            try:
                lbl.config(text=f"{s.read_grams():.1f} g")
            except Exception:
                lbl.config(text="err")
            win.after(300, lambda: refresh(lbl, s))

        refresh()

        Button(frame, text="Tare", width=8,
               command=lambda s=sensor: s.tare()).pack(side=LEFT, padx=4)

        cal_entry = Entry(frame, width=7)
        cal_entry.insert(0, "200")
        cal_entry.pack(side=LEFT, padx=4)
        Label(frame, text="g").pack(side=LEFT)

        status_lbl = Label(frame, text="", fg="green", width=10)
        status_lbl.pack(side=LEFT, padx=4)

        def do_cal(s=sensor, e=cal_entry, lbl=status_lbl):
            try:
                s.calibrate(float(e.get()))
                lbl.config(text="OK")
            except Exception as ex:
                lbl.config(text=str(ex), fg="red")

        Button(frame, text="Calibrate", width=9, command=do_cal).pack(side=LEFT, padx=2)

Button(main, text="Tare & Calibrate", command=open_calibration).pack(pady=4)

# physical button tareing
TARE_BUTTON_PINS = {
    1: 2,   # GPIO1 tares sensor 3 (sensors[2])
    7: 1,   # GPIO7 tares sensor 2 (sensors[1])
    8: 0,   # GPIO8 tares sensor 1 (sensors[0])
}

def make_tare_handler(idx):
    def handler():
        try:
            sensors[idx].tare()
        except IndexError:
            print(f"[GPIO] No sensor at index {idx}")
        except Exception as e:
            print(f"[GPIO] Tare failed for sensor {idx + 1}: {e}")
    return handler

tare_buttons = [] #keep ref to buttons
for pin, sensor_idx in TARE_BUTTON_PINS.items():
    if sensor_idx < len(sensors):
        btn = GPIOButton(pin, pull_up=True)
        btn.when_pressed = make_tare_handler(sensor_idx)
        tare_buttons.append(btn)

FILL_THRESHOLD_G = 150   # start filling if glass is below threshhold
FILL_TARGET_G    = 400   # stop filling when glass reaches threshhold
PID_POLL_MS      = 200   # sensor read interval (ms)

_fill_sensor_idx = 0

#fill innstillinger
Label(main, text=" Fill Settings ", font=("Segoe UI", 11, "bold")).pack(pady=(14, 2))
_fill_frame = Frame(main)
_fill_frame.pack(padx=20, fill="x")

def fill_row(parent, label, default):
    f = Frame(parent)
    f.pack(fill="x", pady=1)
    Label(f, text=label, width=16, anchor="w").pack(side=LEFT)
    var = DoubleVar(value=default)
    Entry(f, textvariable=var, width=8).pack(side=LEFT)
    Label(f, text="g").pack(side=LEFT)
    return var

threshold_var = fill_row(_fill_frame, "Start below (g)",  FILL_THRESHOLD_G)
target_var    = fill_row(_fill_frame, "Fill target (g)",  FILL_TARGET_G)

fill_status = Label(main, text="", fg="gray")
fill_status.pack()

def apply_fill_settings():
    global FILL_THRESHOLD_G, FILL_TARGET_G
    FILL_THRESHOLD_G = threshold_var.get()
    FILL_TARGET_G    = target_var.get()
    fill_status.config(text=f"Threshold={FILL_THRESHOLD_G:.0f}g  Target={FILL_TARGET_G:.0f}g", fg="green")

Button(main, text="Apply Fill Settings", command=apply_fill_settings).pack(pady=4)

def start_fill(idx):
    global fill_state, fill_sensor_idx
    fill_state      = "moving"
    fill_sensor_idx = idx
    go_to(idx)
    root.after(MOVE_STEPS * MOVE_MS + 500, begin_pump)

def begin_pump():
    global fill_state, integral, prev_error, prev_time
    fill_state = "filling"
    pump_fwd.on()
    integral   = 0
    prev_error = 0
    prev_time  = time.time()
    fill_status.config(text="Filling...", fg="blue")
    pid_fill_loop()

def pid_fill_loop():
    global integral, prev_error, prev_time
    if fill_state != "filling":
        return
    try:
        sensors = [hx711.sensor1, hx711.sensor2, hx711.sensor3]
        grams   = sensors[_fill_sensor_idx].read_grams()

        if grams < 0:
            stop_pump()
            fill_status.config(text="Glass lifted — fill cancelled", fg="orange")
            return

        if grams >= FILL_TARGET_G:
            stop_pump()
            return

        output, integral, prev_error, prev_time = pid_control(
            FILL_TARGET_G, grams, integral, prev_error, prev_time
        )
        power = max(5, min(100, int(output)))
        pump_fwd.on()
        desired_duty = int(power / 100 * 65535)
        kit._pca.channels[4].duty_cycle = 65535 - desired_duty
        pump_var.set(power)
        fill_status.config(text=f"Filling: {grams:.0f} / {FILL_TARGET_G:.0f} g  |  pump {power}%", fg="blue")

    except Exception as ex:
        fill_status.config(text=f"Sensor error: {ex}", fg="red")

    root.after(PID_POLL_MS, pid_fill_loop)

def stop_pump():
    global fill_state
    kit._pca.channels[4].duty_cycle = 0
    pump_fwd.off()
    pump_var.set(0)
    fill_state = "idle"
    fill_status.config(text=f"Done — {FILL_TARGET_G:.0f} g reached", fg="green")
    root.after(1000, main_loop)

def main_loop():
    if not activate or fill_state != "idle":
        root.after(500, main_loop)
        return
    sensors = [hx711.sensor1, hx711.sensor2, hx711.sensor3]
    for idx, sensor in enumerate(sensors):
        try:
            grams = sensor.read_grams()
            if grams < 0:
                continue   #løftet glass
            if grams < FILL_THRESHOLD_G:
                start_fill(idx) #fyll glass
                return
        except Exception:
            pass
    root.after(500, main_loop)


#water level
GLASS_MAX_G = 500

Label(main, text=" Water Level ", font=("Segoe UI", 11, "bold")).pack(pady=(10, 2))

bar_vars  = []
bar_grams = []

for name in ["Glass 1", "Glass 2", "Glass 3"]:
    f = Frame(root)
    f.pack(fill="x", padx=20, pady=3)
    Label(f, text=name, width=8, anchor="w").pack(side=LEFT)
    var = IntVar(value=0)
    bar = ttk.Progressbar(f, variable=var, maximum=GLASS_MAX_G, length=300)
    bar.pack(side=LEFT, fill="x", expand=True, padx=4)
    g_lbl = Label(f, text="-- g", width=8, anchor="e")
    g_lbl.pack(side=LEFT)
    bar_vars.append(var)
    bar_grams.append(g_lbl)

def update_bars():
    for var, lbl, sensor in zip(bar_vars, bar_grams,
                                [hx711.sensor1, hx711.sensor2, hx711.sensor3]):
        try:
            g = sensor.read_grams()
            var.set(max(0, min(GLASS_MAX_G, int(g))))
            lbl.config(text=f"{g:.0f} g")
        except Exception:
            lbl.config(text="err")
    root.after(300, update_bars)

#PID verdier
Label(main, text=" PID Controller ", font=("Segoe UI", 11, "bold")).pack(pady=(14, 2))

pid_frame = Frame(main)
pid_frame.pack(padx=20, fill="x")

def pid_row(parent, label, default):
    f = Frame(parent)
    f.pack(fill="x", pady=1)
    Label(f, text=label, width=6, anchor="w").pack(side=LEFT)
    var = DoubleVar(value=default)
    Entry(f, textvariable=var, width=8).pack(side=LEFT)
    return var

pid_kp_var = pid_row(pid_frame, "Kp", kp)
pid_ki_var = pid_row(pid_frame, "Ki", ki)
pid_kd_var = pid_row(pid_frame, "Kd", kd)

pid_status = Label(main, text=f"Active: Kp={kp}  Ki={ki}  Kd={kd}", fg="gray")
pid_status.pack()

def apply_pid():
    global kp, ki, kd, integral, prev_error, prev_time
    kp = pid_kp_var.get()
    ki = pid_ki_var.get()
    kd = pid_kd_var.get()
    integral   = 0
    prev_error = 0
    prev_time  = time.time()
    pid_status.config(text=f"Active: Kp={kp}  Ki={ki}  Kd={kd}", fg="green")

Button(main, text="Apply PID", command=apply_pid).pack(pady=4)

#start
reset_all()
poll_hx711()
update_bars()
main_loop()
root.mainloop()

hx711.sensor1.close()
hx711.sensor2.close()
hx711.sensor3.close()
hx711.sck.close()
pump_fwd.close()
